// CONFIGURACIÓN DE GOOGLE SHEETS
// Reemplaza con tu URL de Apps Script para guardar datos
const GOOGLE_SHEET_URL = "AQUI_PONES_TU_URL";